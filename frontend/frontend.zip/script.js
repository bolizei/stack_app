$(() => {

    $('#button').on('click', (event) => {
        const wert = $('#eingabe').val();

        $.ajax({
            type: "POST",
            url: "http://localhost:3333/verdoppeln",
            data: {
                "wert": wert,
                "von": "frontend"
            },
            dataType: 'JSON',
            crossDomain: true, 
            error: (error) => {
                console.log('error', error);
            },
            success: (response) => {
                $('#b').html(response.wert);
                console.log(response);
            }
        });


        console.log('button clicked');
    })



 
})

